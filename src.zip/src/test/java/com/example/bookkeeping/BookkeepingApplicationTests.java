package com.example.bookkeeping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookkeepingApplicationTests {

    @Test
    void contextLoads() {
    }

}
