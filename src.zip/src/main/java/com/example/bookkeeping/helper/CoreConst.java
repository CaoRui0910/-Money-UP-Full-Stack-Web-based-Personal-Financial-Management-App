package com.example.bookkeeping.helper;

import lombok.experimental.UtilityClass;


@UtilityClass
public class CoreConst {

    public static final String SUCCESS_CODE = "ok";
    public static final String FAIL_CODE = "error";
}
