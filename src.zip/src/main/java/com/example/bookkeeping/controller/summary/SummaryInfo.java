package com.example.bookkeeping.controller.summary;

import lombok.Data;

@Data
public class SummaryInfo {
    private String name;

    private String percent;

    private Integer price;
}
