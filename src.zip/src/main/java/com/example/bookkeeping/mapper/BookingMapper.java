package com.example.bookkeeping.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.bookkeeping.model.Booking;

public interface BookingMapper extends BaseMapper<Booking> {

}

