package com.example.bookkeeping.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.bookkeeping.model.Account;

public interface AccountMapper extends BaseMapper<Account> {

}

